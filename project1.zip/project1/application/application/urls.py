from django.urls import path, include
from list.views import DataHandlerAPIView, listViewSet
from api.views import  list_destinations, DestinationViewSet
from django.contrib import admin
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'list', listViewSet)
router.register(r'destinations', DestinationViewSet)

urlpatterns = [
    path('server/incoming_data/', DataHandlerAPIView.as_view(), name='data_handler'),
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/accounts/<int:account_id>/destinations/', list_destinations),
]
