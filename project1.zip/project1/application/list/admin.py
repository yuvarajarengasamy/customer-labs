from django.contrib import admin
from .models import list
from .models import Destination

admin.site.register(list)

admin.site.register(Destination)

