from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import QueryDict
import requests
from list.models import list, Destination



class DataHandlerAPIView(APIView):
    def post(self, request):
        
        app_secret_token = request.headers.get('CL-X-TOKEN')

        if app_secret_token is None:
            return Response({'error': 'Unauthenticated'}, status=401)

        
        try:
            list = list.objects.get(app_secret_token=app_secret_token)
        except list.DoesNotExist:
            return Response({'error': 'list not found'}, status=404)

       
        destinations = Destination.objects.filter(list=list)

        
        data = request.data

        
        for destination in destinations:
            url = destination.url
            http_method = destination.http_method
            headers = destination.headers

            # Prepare the headers for the request
            request_headers = {
                'Content-Type': 'application/json',
                **headers
            }

            # Send the data to the destination based on the HTTP method
        
            if http_method.lower() == 'get':
                query_params = QueryDict(mutable=True)
                query_params.update(data)
                Response = requests.get(url, headers=request_headers, params=query_params)
            elif http_method.lower() == 'post':
                Response = requests.post(url, headers=request_headers, json=data)
            elif http_method.lower() == 'put':
                Response = requests.put(url, headers=request_headers, json=data)
            else:
                # Handle unsupported HTTP methods here
                Response = None

            # Process the response or handle errors if needed

        return Response({'success': 'Data sent successfully'})
